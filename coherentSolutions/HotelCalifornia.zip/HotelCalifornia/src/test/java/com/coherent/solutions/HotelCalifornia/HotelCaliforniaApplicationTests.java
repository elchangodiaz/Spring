package com.coherent.solutions.HotelCalifornia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelCaliforniaApplicationTests {

	@Test
	void contextLoads() {
	}

}
